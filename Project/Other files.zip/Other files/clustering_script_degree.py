import networkx as nx
from collections import defaultdict
from csv import DictReader
import pandas as pd 
from sklearn.model_selection import train_test_split
from sklearn.metrics import adjusted_mutual_info_score, homogeneity_score
import random
import time
from igraph import *
import numpy as np
from datetime import datetime
from pathlib import Path
from scipy.stats import entropy
import tqdm

p = Path("./data/edgeData").iterdir()
files = [x for x in p if x.is_file() and "2016" not in x.stem and "2017" not in x.stem]

for file_name in files:
	
	print(file_name)
	
	df = pd.read_csv(file_name)
	df["sum"] = df[["h0", "h1", "h2", "h3", "h4", "h5", "h6"]].sum(axis=1)
	# print(len(df))

	edge_tuples = df[["node1", "node2", "sum"]].itertuples(index=False)
	g = Graph.TupleList(edge_tuples, directed=False, weights=True)
	g_weights = g.es["weight"]

	df_res = pd.DataFrame({"degrees": g.degree(g.vs)})

	now = datetime.now()
	date_str = now.strftime("%Y%m%d_%H%M")
	file_name_output = f"degree_dist_{file_name.stem}_res_{date_str}.csv"
	output_path = Path(f"data/res/{file_name_output}")
	df_res.to_csv(output_path, index=False)
